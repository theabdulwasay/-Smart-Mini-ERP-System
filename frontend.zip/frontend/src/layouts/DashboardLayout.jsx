import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Package, ShoppingCart, Users, CreditCard, BarChart3, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const DashboardLayout = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const menuItems = [
        { name: 'Dashboard', path: '/dashboard', icon: <LayoutDashboard size={18} /> },
        { name: 'Inventory', path: '/dashboard/inventory', icon: <Package size={18} /> },
        { name: 'Sales', path: '/dashboard/sales', icon: <ShoppingCart size={18} /> },
        { name: 'Customers', path: '/dashboard/customers', icon: <Users size={18} /> },
        { name: 'Finance', path: '/dashboard/finance', icon: <CreditCard size={18} /> },
        { name: 'Reports', path: '/dashboard/reports', icon: <BarChart3 size={18} /> },
    ];

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <div className="d-flex" style={{ minHeight: '100vh' }}>
            {/* Sidebar */}
            <aside className="sidebar text-white">
                <div className="p-3 border-bottom border-secondary">
                    <h1 className="h4 fw-bold text-primary mb-0">Smart ERP</h1>
                    <small className="text-white-50" style={{ fontSize: '0.75rem' }}>Business Management</small>
                </div>

                <nav className="p-2" style={{ paddingBottom: '80px' }}>
                    {menuItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            end={item.path === '/dashboard'}
                            className={({ isActive }) =>
                                `nav-link d-flex align-items-center gap-2 p-2 rounded mb-1 text-white text-decoration-none ${isActive ? 'active' : ''
                                }`
                            }
                            style={{ fontSize: '0.9rem' }}
                        >
                            {item.icon}
                            <span>{item.name}</span>
                        </NavLink>
                    ))}
                </nav>

                <div className="p-2 position-absolute bottom-0 w-100 border-top border-secondary" style={{ backgroundColor: 'var(--dark-color)', left: 0 }}>
                    <div className="text-white-50 mb-1" style={{ fontSize: '0.75rem' }}>
                        <strong className="text-white d-block">{user?.name || 'User'}</strong>
                        <span className="badge bg-primary" style={{ fontSize: '0.65rem' }}>{user?.role || 'Staff'}</span>
                    </div>
                    <button
                        className="btn btn-link text-danger d-flex align-items-center gap-2 text-decoration-none p-1 w-100"
                        onClick={handleLogout}
                        style={{ fontSize: '0.85rem' }}
                    >
                        <LogOut size={16} />
                        <span>Logout</span>
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="main-content flex-grow-1">
                <header className="bg-white border-bottom p-3 d-flex justify-content-between align-items-center sticky-top shadow-sm">
                    <div>
                        <h2 className="h5 mb-0">Welcome back, {user?.name || 'User'}!</h2>
                        <small className="text-muted">Manage your business efficiently</small>
                    </div>
                    <div className="d-flex align-items-center gap-3">
                        <span className="badge bg-primary">{user?.role || 'Staff'}</span>
                        <div className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold"
                            style={{ width: '40px', height: '40px' }}>
                            {user?.name?.charAt(0).toUpperCase() || 'U'}
                        </div>
                    </div>
                </header>

                <div className="p-4" style={{ maxWidth: '100%', overflowX: 'hidden' }}>
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default DashboardLayout;
