import axios from 'axios';

const API_BASE_URL = 'http://127.0.0.1:5000/api';

// Create axios instance with default config
const api = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Add token to requests if it exists
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Auth API
export const authAPI = {
    login: (credentials) => api.post('/auth/login', credentials),
    register: (userData) => api.post('/auth/register', userData),
    getMe: () => api.get('/auth/me'),
};

// Inventory API
export const inventoryAPI = {
    getAll: () => api.get('/inventory'),
    getById: (id) => api.get(`/inventory/${id}`),
    create: (product) => api.post('/inventory', product),
    update: (id, product) => api.put(`/inventory/${id}`, product),
    delete: (id) => api.delete(`/inventory/${id}`),
};

// Sales API
export const salesAPI = {
    getAll: () => api.get('/sales'),
    getById: (id) => api.get(`/sales/${id}`),
    create: (sale) => api.post('/sales', sale),
};

// Customers API
export const customersAPI = {
    getAll: () => api.get('/customers'),
    getById: (id) => api.get(`/customers/${id}`),
    create: (customer) => api.post('/customers', customer),
    update: (id, customer) => api.put(`/customers/${id}`, customer),
    delete: (id) => api.delete(`/customers/${id}`),
};

// Finance API
export const financeAPI = {
    getExpenses: () => api.get('/finance/expenses'),
    createExpense: (expense) => api.post('/finance/expenses', expense),
    deleteExpense: (id) => api.delete(`/finance/expenses/${id}`),
    getSummary: () => api.get('/finance/summary'),
    getTrends: () => api.get('/finance/trends'),
};

export default api;
