import React, { useState, useEffect } from 'react';
import { ShoppingCart, Plus, Receipt, Calendar } from 'lucide-react';
import { salesAPI, inventoryAPI } from '../services/api';

const Sales = () => {
    const [sales, setSales] = useState([]);
    const [products, setProducts] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [loading, setLoading] = useState(true);
    const [formData, setFormData] = useState({
        customer_name: '',
        items: []
    });
    const [selectedProduct, setSelectedProduct] = useState('');
    const [quantity, setQuantity] = useState(1);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const [salesRes, productsRes] = await Promise.all([
                salesAPI.getAll(),
                inventoryAPI.getAll()
            ]);
            setSales(salesRes.data);
            setProducts(productsRes.data);
        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setLoading(false);
        }
    };

    const addItemToCart = () => {
        if (!selectedProduct || quantity < 1) return;

        const product = products.find(p => p.id === parseInt(selectedProduct));
        if (!product) return;

        const existingItem = formData.items.find(item => item.product_id === product.id);

        if (existingItem) {
            setFormData({
                ...formData,
                items: formData.items.map(item =>
                    item.product_id === product.id
                        ? { ...item, qty: item.qty + quantity }
                        : item
                )
            });
        } else {
            setFormData({
                ...formData,
                items: [...formData.items, {
                    product_id: product.id,
                    product_name: product.name,
                    price: product.price,
                    qty: quantity
                }]
            });
        }

        setSelectedProduct('');
        setQuantity(1);
    };

    const removeItem = (productId) => {
        setFormData({
            ...formData,
            items: formData.items.filter(item => item.product_id !== productId)
        });
    };

    const calculateTotal = () => {
        return formData.items.reduce((sum, item) => sum + (item.price * item.qty), 0);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (formData.items.length === 0) {
            alert('Please add at least one item to the sale');
            return;
        }

        try {
            await salesAPI.create({
                customer_name: formData.customer_name || 'Walk-in Customer',
                items: formData.items
            });
            fetchData();
            handleCloseModal();
        } catch (error) {
            alert(error.response?.data?.msg || 'Error creating sale');
        }
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setFormData({ customer_name: '', items: [] });
        setSelectedProduct('');
        setQuantity(1);
    };

    return (
        <div>
            {/* Header */}
            <div className="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 className="h3 fw-bold mb-1">Sales & POS</h2>
                    <p className="text-muted">Record sales and view transaction history</p>
                </div>
                <button className="btn btn-primary" onClick={() => setShowModal(true)}>
                    <Plus size={18} className="me-2" />
                    New Sale
                </button>
            </div>

            {/* Stats Cards */}
            <div className="row g-4 mb-4">
                <div className="col-md-4">
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <p className="text-muted small mb-1">Today's Sales</p>
                                    <h3 className="h4 fw-bold mb-0">
                                        ${sales.filter(s => new Date(s.created_at).toDateString() === new Date().toDateString())
                                            .reduce((sum, s) => sum + parseFloat(s.total), 0).toFixed(2)}
                                    </h3>
                                </div>
                                <div className="bg-primary bg-opacity-10 p-3 rounded">
                                    <ShoppingCart className="text-primary" size={24} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <p className="text-muted small mb-1">Total Transactions</p>
                                    <h3 className="h4 fw-bold mb-0">{sales.length}</h3>
                                </div>
                                <div className="bg-success bg-opacity-10 p-3 rounded">
                                    <Receipt className="text-success" size={24} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <p className="text-muted small mb-1">Average Sale</p>
                                    <h3 className="h4 fw-bold mb-0">
                                        ${sales.length > 0 ? (sales.reduce((sum, s) => sum + parseFloat(s.total), 0) / sales.length).toFixed(2) : '0.00'}
                                    </h3>
                                </div>
                                <div className="bg-info bg-opacity-10 p-3 rounded">
                                    <Calendar className="text-info" size={24} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Sales History */}
            <div className="card">
                <div className="card-header bg-white">
                    <h5 className="mb-0">Recent Transactions</h5>
                </div>
                <div className="card-body">
                    {loading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border text-primary"></div>
                        </div>
                    ) : (
                        <div className="table-responsive">
                            <table className="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Customer</th>
                                        <th>Items</th>
                                        <th>Total</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sales.slice().reverse().map((sale) => (
                                        <tr key={sale.id}>
                                            <td className="fw-semibold">#{sale.id}</td>
                                            <td>{sale.customer_name}</td>
                                            <td>{sale.items_count} item(s)</td>
                                            <td className="fw-bold text-success">${parseFloat(sale.total).toFixed(2)}</td>
                                            <td>{new Date(sale.created_at).toLocaleString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {sales.length === 0 && (
                                <div className="text-center py-5 text-muted">
                                    <Receipt size={48} className="mb-3 opacity-50" />
                                    <p>No sales recorded yet</p>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>

            {/* New Sale Modal */}
            {showModal && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">New Sale</h5>
                                <button type="button" className="btn-close" onClick={handleCloseModal}></button>
                            </div>
                            <form onSubmit={handleSubmit}>
                                <div className="modal-body">
                                    <div className="mb-4">
                                        <label className="form-label">Customer Name (Optional)</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            value={formData.customer_name}
                                            onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                                            placeholder="Walk-in Customer"
                                        />
                                    </div>

                                    <div className="card mb-3">
                                        <div className="card-header bg-light">
                                            <strong>Add Items</strong>
                                        </div>
                                        <div className="card-body">
                                            <div className="row g-3">
                                                <div className="col-md-6">
                                                    <select
                                                        className="form-select"
                                                        value={selectedProduct}
                                                        onChange={(e) => setSelectedProduct(e.target.value)}
                                                    >
                                                        <option value="">Select Product</option>
                                                        {products.map(p => (
                                                            <option key={p.id} value={p.id}>
                                                                {p.name} - ${p.price} (Stock: {p.stock})
                                                            </option>
                                                        ))}
                                                    </select>
                                                </div>
                                                <div className="col-md-3">
                                                    <input
                                                        type="number"
                                                        className="form-control"
                                                        placeholder="Qty"
                                                        min="1"
                                                        value={quantity}
                                                        onChange={(e) => setQuantity(parseInt(e.target.value))}
                                                    />
                                                </div>
                                                <div className="col-md-3">
                                                    <button
                                                        type="button"
                                                        className="btn btn-primary w-100"
                                                        onClick={addItemToCart}
                                                    >
                                                        Add
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Cart Items */}
                                    {formData.items.length > 0 && (
                                        <div className="table-responsive">
                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        <th>Product</th>
                                                        <th>Price</th>
                                                        <th>Qty</th>
                                                        <th>Subtotal</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {formData.items.map((item) => (
                                                        <tr key={item.product_id}>
                                                            <td>{item.product_name}</td>
                                                            <td>${parseFloat(item.price).toFixed(2)}</td>
                                                            <td>{item.qty}</td>
                                                            <td className="fw-bold">${(item.price * item.qty).toFixed(2)}</td>
                                                            <td>
                                                                <button
                                                                    type="button"
                                                                    className="btn btn-sm btn-outline-danger"
                                                                    onClick={() => removeItem(item.product_id)}
                                                                >
                                                                    Remove
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colSpan="3" className="text-end fw-bold">Total:</td>
                                                        <td className="fw-bold text-success fs-5">${calculateTotal().toFixed(2)}</td>
                                                        <td></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    )}
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>
                                        Cancel
                                    </button>
                                    <button type="submit" className="btn btn-primary">
                                        Complete Sale
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Sales;
