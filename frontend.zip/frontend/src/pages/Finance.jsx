import React, { useState } from 'react';
import { DollarSign, TrendingUp, TrendingDown, Plus, Calendar } from 'lucide-react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const Finance = () => {
    const [expenses, setExpenses] = useState([
        { id: 1, title: 'Office Rent', amount: 2500, category: 'Rent', date: '2026-02-01' },
        { id: 2, title: 'Utilities', amount: 450, category: 'Utilities', date: '2026-02-05' },
        { id: 3, title: 'Salaries', amount: 8500, category: 'Payroll', date: '2026-02-01' },
        { id: 4, title: 'Marketing', amount: 1200, category: 'Marketing', date: '2026-02-07' },
    ]);
    const [showModal, setShowModal] = useState(false);
    const [formData, setFormData] = useState({
        title: '',
        amount: '',
        category: '',
        date: new Date().toISOString().split('T')[0]
    });

    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const totalIncome = 45200; // Mock data
    const profit = totalIncome - totalExpenses;

    const chartData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'Income',
                data: [35000, 42000, 38000, 45000, 48000, 45200],
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
            },
            {
                label: 'Expenses',
                data: [28000, 30000, 29000, 31000, 32000, totalExpenses],
                borderColor: '#ef4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                tension: 0.4,
            },
        ],
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const newExpense = {
            id: expenses.length + 1,
            ...formData,
            amount: parseFloat(formData.amount)
        };
        setExpenses([...expenses, newExpense]);
        setShowModal(false);
        setFormData({ title: '', amount: '', category: '', date: new Date().toISOString().split('T')[0] });
    };

    return (
        <div>
            {/* Header */}
            <div className="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 className="h3 fw-bold mb-1">Finance & Accounts</h2>
                    <p className="text-muted">Track income, expenses, and profitability</p>
                </div>
                <button className="btn btn-primary" onClick={() => setShowModal(true)}>
                    <Plus size={18} className="me-2" />
                    Add Expense
                </button>
            </div>

            {/* Financial Overview */}
            <div className="row g-4 mb-4">
                <div className="col-md-4">
                    <div className="card border-success">
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-start">
                                <div>
                                    <p className="text-muted small mb-1">Total Income</p>
                                    <h3 className="h4 fw-bold text-success mb-2">${totalIncome.toLocaleString()}</h3>
                                    <small className="text-success">
                                        <TrendingUp size={14} className="me-1" />
                                        +15.3% from last month
                                    </small>
                                </div>
                                <div className="bg-success bg-opacity-10 p-3 rounded">
                                    <TrendingUp className="text-success" size={24} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="card border-danger">
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-start">
                                <div>
                                    <p className="text-muted small mb-1">Total Expenses</p>
                                    <h3 className="h4 fw-bold text-danger mb-2">${totalExpenses.toLocaleString()}</h3>
                                    <small className="text-danger">
                                        <TrendingDown size={14} className="me-1" />
                                        +5.2% from last month
                                    </small>
                                </div>
                                <div className="bg-danger bg-opacity-10 p-3 rounded">
                                    <TrendingDown className="text-danger" size={24} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="card border-primary">
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-start">
                                <div>
                                    <p className="text-muted small mb-1">Net Profit</p>
                                    <h3 className="h4 fw-bold text-primary mb-2">${profit.toLocaleString()}</h3>
                                    <small className="text-primary">
                                        Profit Margin: {((profit / totalIncome) * 100).toFixed(1)}%
                                    </small>
                                </div>
                                <div className="bg-primary bg-opacity-10 p-3 rounded">
                                    <DollarSign className="text-primary" size={24} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Income vs Expenses Chart */}
            <div className="card mb-4">
                <div className="card-header bg-white">
                    <h5 className="mb-0">Income vs Expenses Trend</h5>
                </div>
                <div className="card-body">
                    <div style={{ height: '300px' }}>
                        <Line data={chartData} options={{ maintainAspectRatio: false, responsive: true }} />
                    </div>
                </div>
            </div>

            {/* Expenses Table */}
            <div className="card">
                <div className="card-header bg-white">
                    <h5 className="mb-0">Recent Expenses</h5>
                </div>
                <div className="card-body">
                    <div className="table-responsive">
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {expenses.slice().reverse().map((expense) => (
                                    <tr key={expense.id}>
                                        <td>
                                            <Calendar size={14} className="me-2" />
                                            {new Date(expense.date).toLocaleDateString()}
                                        </td>
                                        <td className="fw-semibold">{expense.title}</td>
                                        <td>
                                            <span className="badge bg-secondary">{expense.category}</span>
                                        </td>
                                        <td className="fw-bold text-danger">-${expense.amount.toLocaleString()}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* Add Expense Modal */}
            {showModal && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Add New Expense</h5>
                                <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                            </div>
                            <form onSubmit={handleSubmit}>
                                <div className="modal-body">
                                    <div className="mb-3">
                                        <label className="form-label">Description</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            value={formData.title}
                                            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Amount ($)</label>
                                        <input
                                            type="number"
                                            step="0.01"
                                            className="form-control"
                                            value={formData.amount}
                                            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Category</label>
                                        <select
                                            className="form-select"
                                            value={formData.category}
                                            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                                            required
                                        >
                                            <option value="">Select Category</option>
                                            <option value="Rent">Rent</option>
                                            <option value="Utilities">Utilities</option>
                                            <option value="Payroll">Payroll</option>
                                            <option value="Marketing">Marketing</option>
                                            <option value="Supplies">Supplies</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Date</label>
                                        <input
                                            type="date"
                                            className="form-control"
                                            value={formData.date}
                                            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                                            required
                                        />
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                                        Cancel
                                    </button>
                                    <button type="submit" className="btn btn-primary">
                                        Add Expense
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Finance;
