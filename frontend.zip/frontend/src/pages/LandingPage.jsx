import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, BarChart3, Package, Users, TrendingUp, Shield, Zap } from 'lucide-react';

const LandingPage = () => {
    const navigate = useNavigate();

    const features = [
        { icon: <Package size={32} />, title: 'Inventory Management', desc: 'Track products and stock levels in real-time' },
        { icon: <BarChart3 size={32} />, title: 'Sales Analytics', desc: 'Comprehensive reports and insights' },
        { icon: <Users size={32} />, title: 'Customer CRM', desc: 'Manage customer relationships effectively' },
        { icon: <TrendingUp size={32} />, title: 'AI Insights', desc: 'Smart business recommendations' },
        { icon: <Shield size={32} />, title: 'Secure & Reliable', desc: 'Enterprise-grade security' },
        { icon: <Zap size={32} />, title: 'Fast & Modern', desc: 'Lightning-fast performance' },
    ];

    return (
        <div className="min-vh-100">
            {/* Hero Section */}
            <section className="bg-gradient-to-br from-primary to-dark text-white" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e293b 100%)',
                minHeight: '100vh'
            }}>
                <nav className="navbar navbar-expand-lg navbar-dark py-3">
                    <div className="container">
                        <a className="navbar-brand fw-bold fs-3" href="#">
                            <span className="text-white">Smart</span><span className="text-warning">ERP</span>
                        </a>
                        <div className="ms-auto">
                            <button className="btn btn-outline-light me-2" onClick={() => navigate('/login')}>
                                Login
                            </button>
                            <button className="btn btn-warning text-dark fw-semibold" onClick={() => navigate('/login')}>
                                Get Started
                            </button>
                        </div>
                    </div>
                </nav>

                <div className="container">
                    <div className="row align-items-center" style={{ minHeight: '80vh' }}>
                        <div className="col-lg-6">
                            <h1 className="display-3 fw-bold mb-4">
                                Manage Your Business with <span className="text-warning">AI-Powered</span> ERP
                            </h1>
                            <p className="lead mb-4 text-white-50">
                                Complete business management solution for small businesses. Track inventory, manage sales,
                                analyze finances, and grow your business with intelligent insights.
                            </p>
                            <div className="d-flex gap-3">
                                <button
                                    className="btn btn-warning btn-lg text-dark fw-semibold px-4"
                                    onClick={() => navigate('/login')}
                                >
                                    Start Free Trial
                                    <ArrowRight size={20} className="ms-2" />
                                </button>
                                <button className="btn btn-outline-light btn-lg px-4">
                                    Watch Demo
                                </button>
                            </div>
                            <div className="mt-5 d-flex gap-4 text-white-50">
                                <div>
                                    <div className="h3 fw-bold text-white">1000+</div>
                                    <small>Active Users</small>
                                </div>
                                <div>
                                    <div className="h3 fw-bold text-white">99.9%</div>
                                    <small>Uptime</small>
                                </div>
                                <div>
                                    <div className="h3 fw-bold text-white">24/7</div>
                                    <small>Support</small>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="position-relative">
                                <div className="card bg-white bg-opacity-10 backdrop-blur border-0 p-4 shadow-lg">
                                    <div className="card-body">
                                        <div className="d-flex justify-content-between mb-3">
                                            <div className="text-white">
                                                <small className="text-white-50">Total Revenue</small>
                                                <h3 className="fw-bold mb-0">$254,800</h3>
                                            </div>
                                            <div className="bg-success bg-opacity-25 p-3 rounded">
                                                <TrendingUp className="text-success" size={24} />
                                            </div>
                                        </div>
                                        <div className="progress mb-2" style={{ height: '8px' }}>
                                            <div className="progress-bar bg-success" style={{ width: '75%' }}></div>
                                        </div>
                                        <small className="text-success">↑ 18.2% from last month</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section className="py-5 bg-light">
                <div className="container py-5">
                    <div className="text-center mb-5">
                        <h2 className="display-5 fw-bold mb-3">Everything You Need to Run Your Business</h2>
                        <p className="lead text-muted">Powerful features designed for small businesses</p>
                    </div>
                    <div className="row g-4">
                        {features.map((feature, index) => (
                            <div key={index} className="col-md-4">
                                <div className="card h-100 border-0 shadow-sm hover-lift" style={{ transition: 'transform 0.3s' }}>
                                    <div className="card-body p-4">
                                        <div className="bg-primary bg-opacity-10 p-3 rounded mb-3 d-inline-block text-primary">
                                            {feature.icon}
                                        </div>
                                        <h5 className="fw-bold mb-2">{feature.title}</h5>
                                        <p className="text-muted mb-0">{feature.desc}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-5 bg-primary text-white">
                <div className="container py-5 text-center">
                    <h2 className="display-5 fw-bold mb-4">Ready to Transform Your Business?</h2>
                    <p className="lead mb-4">Join thousands of businesses already using Smart ERP</p>
                    <button
                        className="btn btn-warning btn-lg text-dark fw-semibold px-5"
                        onClick={() => navigate('/login')}
                    >
                        Get Started Now
                        <ArrowRight size={20} className="ms-2" />
                    </button>
                </div>
            </section>

            {/* Footer */}
            <footer className="bg-dark text-white py-4">
                <div className="container text-center">
                    <p className="mb-0">&copy; 2026 Smart ERP. All rights reserved.</p>
                </div>
            </footer>
        </div>
    );
};

export default LandingPage;
