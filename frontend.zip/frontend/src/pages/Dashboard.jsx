import React from 'react';
import { TrendingUp, Package, Users, DollarSign } from 'lucide-react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const Dashboard = () => {
    const stats = [
        { title: 'Total Sales', value: '$12,450', icon: <DollarSign className="text-primary" size={32} />, trend: '+12.5%', color: 'primary' },
        { title: 'Total Products', value: '145', icon: <Package className="text-success" size={32} />, trend: 'Low Stock: 5', color: 'success' },
        { title: 'Total Customers', value: '1,240', icon: <Users className="text-info" size={32} />, trend: '+8.2%', color: 'info' },
        { title: 'Monthly Revenue', value: '$45,200', icon: <TrendingUp className="text-warning" size={32} />, trend: '+15.3%', color: 'warning' },
    ];

    const chartData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'Sales Revenue ($)',
                data: [12000, 19000, 15000, 22000, 30000, 28000],
                backgroundColor: '#3b82f6',
                borderRadius: 8,
            },
        ],
    };

    return (
        <div>
            {/* Stats Grid */}
            <div className="row g-4 mb-4">
                {stats.map((stat, index) => (
                    <div key={index} className="col-md-6 col-lg-3">
                        <div className="card stat-card p-4">
                            <div className="d-flex justify-content-between align-items-start">
                                <div>
                                    <p className="text-muted small mb-1">{stat.title}</p>
                                    <h3 className="h2 fw-bold mb-2">{stat.value}</h3>
                                    <p className="small mb-0">
                                        <span className={stat.trend.includes('+') ? 'text-success fw-semibold' : 'text-muted'}>
                                            {stat.trend}
                                        </span> vs last month
                                    </p>
                                </div>
                                <div className="bg-light p-3 rounded">
                                    {stat.icon}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Chart & AI Insights */}
            <div className="row g-4">
                <div className="col-lg-8">
                    <div className="card p-4">
                        <h3 className="h5 fw-semibold mb-4">Sales Performance</h3>
                        <div style={{ height: '300px' }}>
                            <Bar data={chartData} options={{ maintainAspectRatio: false, responsive: true }} />
                        </div>
                    </div>
                </div>

                <div className="col-lg-4">
                    <div className="insight-card p-4">
                        <h3 className="h5 fw-semibold mb-4 d-flex align-items-center gap-2">
                            <span className="badge bg-primary rounded-circle p-1" style={{ width: '10px', height: '10px' }}></span>
                            AI Business Insights
                        </h3>
                        <div className="d-flex flex-column gap-3">
                            <div className="bg-white bg-opacity-10 p-3 rounded border border-white border-opacity-10">
                                <p className="text-info small fw-semibold mb-1">Demand Forecast</p>
                                <p className="small mb-0 text-white-50">Expected 15% increase in Electronics category next week. Restock recommended.</p>
                            </div>
                            <div className="bg-white bg-opacity-10 p-3 rounded border border-white border-opacity-10">
                                <p className="text-success small fw-semibold mb-1">Inventory Alert</p>
                                <p className="small mb-0 text-white-50">Product "Wireless Mouse" is selling 2x faster than usual. Only 5 left in stock.</p>
                            </div>
                            <div className="bg-white bg-opacity-10 p-3 rounded border border-white border-opacity-10">
                                <p className="text-warning small fw-semibold mb-1">Profit Opportunity</p>
                                <p className="small mb-0 text-white-50">Bundle "Monitor" with "HDMI Cable" to increase average order value by 12%.</p>
                            </div>
                        </div>
                        <button className="btn btn-primary w-100 mt-4">
                            View Full Analysis
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
