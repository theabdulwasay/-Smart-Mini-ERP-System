import React, { useState } from 'react';
import { Users, Plus, Mail, Phone, MapPin, Calendar } from 'lucide-react';

const Customers = () => {
    const [customers, setCustomers] = useState([
        { id: 1, name: 'John Doe', email: 'john@example.com', phone: '+1234567890', address: '123 Main St', totalPurchases: 5420, lastVisit: '2026-02-08' },
        { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '+1234567891', address: '456 Oak Ave', totalPurchases: 3200, lastVisit: '2026-02-07' },
        { id: 3, name: 'Bob Johnson', email: 'bob@example.com', phone: '+1234567892', address: '789 Pine Rd', totalPurchases: 8900, lastVisit: '2026-02-09' },
    ]);
    const [showModal, setShowModal] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        address: ''
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        const newCustomer = {
            id: customers.length + 1,
            ...formData,
            totalPurchases: 0,
            lastVisit: new Date().toISOString().split('T')[0]
        };
        setCustomers([...customers, newCustomer]);
        setShowModal(false);
        setFormData({ name: '', email: '', phone: '', address: '' });
    };

    return (
        <div>
            {/* Header */}
            <div className="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 className="h3 fw-bold mb-1">Customer Management</h2>
                    <p className="text-muted">Manage customer relationships and track purchase history</p>
                </div>
                <button className="btn btn-primary" onClick={() => setShowModal(true)}>
                    <Plus size={18} className="me-2" />
                    Add Customer
                </button>
            </div>

            {/* Stats */}
            <div className="row g-4 mb-4">
                <div className="col-md-3">
                    <div className="card">
                        <div className="card-body">
                            <p className="text-muted small mb-1">Total Customers</p>
                            <h3 className="h4 fw-bold mb-0">{customers.length}</h3>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card">
                        <div className="card-body">
                            <p className="text-muted small mb-1">Active This Month</p>
                            <h3 className="h4 fw-bold mb-0 text-success">{customers.filter(c => new Date(c.lastVisit).getMonth() === new Date().getMonth()).length}</h3>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card">
                        <div className="card-body">
                            <p className="text-muted small mb-1">Total Revenue</p>
                            <h3 className="h4 fw-bold mb-0 text-primary">
                                ${customers.reduce((sum, c) => sum + c.totalPurchases, 0).toLocaleString()}
                            </h3>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card">
                        <div className="card-body">
                            <p className="text-muted small mb-1">Avg Purchase Value</p>
                            <h3 className="h4 fw-bold mb-0">
                                ${(customers.reduce((sum, c) => sum + c.totalPurchases, 0) / customers.length).toFixed(2)}
                            </h3>
                        </div>
                    </div>
                </div>
            </div>

            {/* Customers Table */}
            <div className="card">
                <div className="card-body">
                    <div className="table-responsive">
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Contact</th>
                                    <th>Address</th>
                                    <th>Total Purchases</th>
                                    <th>Last Visit</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {customers.map((customer) => (
                                    <tr key={customer.id}>
                                        <td>
                                            <div className="d-flex align-items-center">
                                                <div className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3"
                                                    style={{ width: '40px', height: '40px' }}>
                                                    {customer.name.charAt(0)}
                                                </div>
                                                <div>
                                                    <div className="fw-semibold">{customer.name}</div>
                                                    <small className="text-muted">ID: #{customer.id}</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div className="small">
                                                <div className="mb-1"><Mail size={14} className="me-1" />{customer.email}</div>
                                                <div><Phone size={14} className="me-1" />{customer.phone}</div>
                                            </div>
                                        </td>
                                        <td>
                                            <small><MapPin size={14} className="me-1" />{customer.address}</small>
                                        </td>
                                        <td className="fw-bold text-success">${customer.totalPurchases.toLocaleString()}</td>
                                        <td>
                                            <small><Calendar size={14} className="me-1" />{new Date(customer.lastVisit).toLocaleDateString()}</small>
                                        </td>
                                        <td>
                                            <span className={`badge ${customer.totalPurchases > 5000 ? 'bg-warning' : 'bg-info'}`}>
                                                {customer.totalPurchases > 5000 ? 'VIP' : 'Regular'}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* Add Customer Modal */}
            {showModal && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Add New Customer</h5>
                                <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                            </div>
                            <form onSubmit={handleSubmit}>
                                <div className="modal-body">
                                    <div className="mb-3">
                                        <label className="form-label">Full Name</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            value={formData.name}
                                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Email</label>
                                        <input
                                            type="email"
                                            className="form-control"
                                            value={formData.email}
                                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Phone</label>
                                        <input
                                            type="tel"
                                            className="form-control"
                                            value={formData.phone}
                                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Address</label>
                                        <textarea
                                            className="form-control"
                                            rows="2"
                                            value={formData.address}
                                            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                                            required
                                        ></textarea>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                                        Cancel
                                    </button>
                                    <button type="submit" className="btn btn-primary">
                                        Add Customer
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Customers;
