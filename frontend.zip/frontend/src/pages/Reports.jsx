import React from 'react';
import { BarChart3, Download, TrendingUp, Package, Users, DollarSign } from 'lucide-react';
import { Doughnut, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const Reports = () => {
    const salesByCategory = {
        labels: ['Electronics', 'Clothing', 'Food', 'Books', 'Other'],
        datasets: [{
            data: [35, 25, 20, 12, 8],
            backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
        }]
    };

    const monthlyPerformance = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Revenue ($)',
            data: [35000, 42000, 38000, 45000, 48000, 45200],
            backgroundColor: '#3b82f6',
        }]
    };

    const topProducts = [
        { name: 'Wireless Mouse', sold: 245, revenue: 4900 },
        { name: 'USB Cable', sold: 189, revenue: 1890 },
        { name: 'Keyboard', sold: 156, revenue: 7800 },
        { name: 'Monitor', sold: 98, revenue: 19600 },
        { name: 'Headphones', sold: 87, revenue: 4350 },
    ];

    const exportReport = (type) => {
        alert(`Exporting ${type} report...`);
    };

    return (
        <div>
            {/* Header */}
            <div className="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 className="h3 fw-bold mb-1">Business Reports & Analytics</h2>
                    <p className="text-muted">Comprehensive insights into your business performance</p>
                </div>
                <div className="btn-group">
                    <button className="btn btn-outline-primary" onClick={() => exportReport('PDF')}>
                        <Download size={18} className="me-2" />
                        Export PDF
                    </button>
                    <button className="btn btn-outline-success" onClick={() => exportReport('Excel')}>
                        <Download size={18} className="me-2" />
                        Export Excel
                    </button>
                </div>
            </div>

            {/* KPI Summary */}
            <div className="row g-4 mb-4">
                <div className="col-md-3">
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-between">
                                <div>
                                    <p className="text-muted small mb-1">Total Revenue</p>
                                    <h4 className="fw-bold mb-0">$254,800</h4>
                                    <small className="text-success">
                                        <TrendingUp size={12} /> +18.2%
                                    </small>
                                </div>
                                <DollarSign className="text-primary" size={32} />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-between">
                                <div>
                                    <p className="text-muted small mb-1">Products Sold</p>
                                    <h4 className="fw-bold mb-0">1,245</h4>
                                    <small className="text-success">
                                        <TrendingUp size={12} /> +12.5%
                                    </small>
                                </div>
                                <Package className="text-success" size={32} />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-between">
                                <div>
                                    <p className="text-muted small mb-1">New Customers</p>
                                    <h4 className="fw-bold mb-0">342</h4>
                                    <small className="text-success">
                                        <TrendingUp size={12} /> +8.7%
                                    </small>
                                </div>
                                <Users className="text-info" size={32} />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-between">
                                <div>
                                    <p className="text-muted small mb-1">Avg Order Value</p>
                                    <h4 className="fw-bold mb-0">$204.66</h4>
                                    <small className="text-success">
                                        <TrendingUp size={12} /> +5.3%
                                    </small>
                                </div>
                                <BarChart3 className="text-warning" size={32} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Charts */}
            <div className="row g-4 mb-4">
                <div className="col-md-8">
                    <div className="card">
                        <div className="card-header bg-white">
                            <h5 className="mb-0">Monthly Performance</h5>
                        </div>
                        <div className="card-body">
                            <div style={{ height: '300px' }}>
                                <Bar data={monthlyPerformance} options={{ maintainAspectRatio: false, responsive: true }} />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="card">
                        <div className="card-header bg-white">
                            <h5 className="mb-0">Sales by Category</h5>
                        </div>
                        <div className="card-body">
                            <div style={{ height: '300px' }} className="d-flex align-items-center justify-content-center">
                                <Doughnut data={salesByCategory} options={{ maintainAspectRatio: false, responsive: true }} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Top Products */}
            <div className="card">
                <div className="card-header bg-white">
                    <h5 className="mb-0">Top Selling Products</h5>
                </div>
                <div className="card-body">
                    <div className="table-responsive">
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Product Name</th>
                                    <th>Units Sold</th>
                                    <th>Revenue</th>
                                    <th>Performance</th>
                                </tr>
                            </thead>
                            <tbody>
                                {topProducts.map((product, index) => (
                                    <tr key={index}>
                                        <td>
                                            <span className={`badge ${index === 0 ? 'bg-warning' : index === 1 ? 'bg-secondary' : 'bg-light text-dark'}`}>
                                                #{index + 1}
                                            </span>
                                        </td>
                                        <td className="fw-semibold">{product.name}</td>
                                        <td>{product.sold} units</td>
                                        <td className="fw-bold text-success">${product.revenue.toLocaleString()}</td>
                                        <td>
                                            <div className="progress" style={{ height: '8px' }}>
                                                <div
                                                    className="progress-bar bg-success"
                                                    style={{ width: `${(product.sold / topProducts[0].sold) * 100}%` }}
                                                ></div>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Reports;
