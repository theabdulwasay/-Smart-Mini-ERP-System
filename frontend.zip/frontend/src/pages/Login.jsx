import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogIn, UserPlus, ArrowLeft } from 'lucide-react';

const Login = () => {
    const [isLogin, setIsLogin] = useState(true);
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        name: '',
        role: 'admin'
    });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const { login, register } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            if (isLogin) {
                await login({ email: formData.email, password: formData.password });
                navigate('/dashboard');
            } else {
                await register(formData);
                setIsLogin(true);
                setError('Registration successful! Please login.');
            }
        } catch (err) {
            setError(err.response?.data?.msg || 'An error occurred');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-vh-100 d-flex align-items-center justify-content-center bg-light">
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-md-5">
                        <div className="card shadow-lg border-0">
                            <div className="card-body p-5">
                                <Link to="/" className="text-decoration-none text-muted d-flex align-items-center mb-4" style={{ width: 'fit-content' }}>
                                    <ArrowLeft size={20} className="me-2" />
                                    Back to Home
                                </Link>
                                <div className="text-center mb-4">
                                    <h1 className="h3 fw-bold text-primary">Smart ERP</h1>
                                    <p className="text-muted">
                                        {isLogin ? 'Sign in to your account' : 'Create admin account'}
                                    </p>
                                </div>

                                {error && (
                                    <div className={`alert ${error.includes('successful') ? 'alert-success' : 'alert-danger'}`}>
                                        {error}
                                    </div>
                                )}

                                <form onSubmit={handleSubmit}>
                                    {!isLogin && (
                                        <div className="mb-3">
                                            <label className="form-label">Full Name</label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                value={formData.name}
                                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                                required={!isLogin}
                                            />
                                        </div>
                                    )}

                                    <div className="mb-3">
                                        <label className="form-label">Email Address</label>
                                        <input
                                            type="email"
                                            className="form-control"
                                            value={formData.email}
                                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                            required
                                        />
                                    </div>

                                    <div className="mb-3">
                                        <label className="form-label">Password</label>
                                        <input
                                            type="password"
                                            className="form-control"
                                            value={formData.password}
                                            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                            required
                                        />
                                    </div>

                                    <button
                                        type="submit"
                                        className="btn btn-primary w-100 mb-3"
                                        disabled={loading}
                                    >
                                        {loading ? (
                                            <span className="spinner-border spinner-border-sm me-2"></span>
                                        ) : isLogin ? (
                                            <LogIn size={18} className="me-2" />
                                        ) : (
                                            <UserPlus size={18} className="me-2" />
                                        )}
                                        {isLogin ? 'Sign In' : 'Sign Up as Admin'}
                                    </button>
                                </form>

                                <div className="text-center">
                                    <button
                                        className="btn btn-link text-decoration-none"
                                        onClick={() => {
                                            setIsLogin(!isLogin);
                                            setError('');
                                        }}
                                    >
                                        {isLogin ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
                                    </button>
                                </div>

                                {isLogin && (
                                    <div className="mt-4 p-3 bg-light rounded">
                                        <small className="text-muted">
                                            <strong>Demo Credentials:</strong><br />
                                            Email: admin@smarterp.com<br />
                                            Password: admin123
                                        </small>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
